#pragma once
#include <Arduino.h>
#include "secrets.h"

// ---------------------------------------------------------------------------
// JARVIS - central configuration.  Everything you are likely to edit is here.
// ---------------------------------------------------------------------------

#define FW_NAME      "JARVIS"
#define FW_VERSION   "1.0.0"

// ---- Wi-Fi access point ---------------------------------------------------
static const uint8_t JARVIS_AP_CHANNEL     = 6;
static const uint8_t JARVIS_AP_MAX_CLIENTS = 4;      // ESP32 hard limit is 10
static const bool    JARVIS_AP_HIDDEN      = false;

// ---- Bluetooth (BLE advertising only; see README for Classic BT) ----------
#define BLE_DEVICE_NAME "JARVIS"

// ---- Authentication -------------------------------------------------------
static const uint32_t SESSION_IDLE_TIMEOUT_MS = 30UL * 60UL * 1000UL;  // 30 min
static const uint8_t  MAX_SESSIONS            = 3;
static const uint8_t  LOGIN_MAX_FAILS         = 5;      // wrong tries per IP...
static const uint32_t LOGIN_LOCK_MS           = 60000;  // ...then lock 60 s
                                                        // (doubles per repeat, max x8)

// ---- I2C bus used by the "peripherals" scanner ----------------------------
static const uint8_t I2C_SDA = 21;
static const uint8_t I2C_SCL = 22;

// ---------------------------------------------------------------------------
// GPIO OUTPUTS the dashboard may control.
// Only pins listed here exist as far as the web API is concerned.
// JARVIS cannot detect what is wired to a pin - if you add a relay here,
// you must have wired it (with a driver / transistor where needed).
//
// Allowed output pins (enforced at boot, see Hardware::isSafeOutputPin):
//   2 4 5 13 14 15 16 17 18 19 23 25 26 27 32 33
// Everything else (flash pins 6-11, UART 1/3, strapping 0/12, input-only
// 34-39, I2C 21/22) is refused and shown as BLOCKED.
// ---------------------------------------------------------------------------
struct OutputPin {
  uint8_t     pin;
  const char* name;       // shown in the UI, keep it short, A-Z 0-9 _
  bool        activeHigh; // true: HIGH = ON.  false: LOW = ON (e.g. relay boards)
  bool        initialOn;  // state applied at boot
};

static const OutputPin OUTPUTS[] = {
  { 2, "ONBOARD_LED", true, false },   // blue LED on most ESP32 DevKit boards
  // { 4,  "LED_EXT_1", true,  false },   // <- uncomment after wiring LED + resistor
  // { 16, "RELAY_1",   false, false },   // <- active-LOW relay module example
};
static const size_t OUTPUT_COUNT = sizeof(OUTPUTS) / sizeof(OUTPUTS[0]);

// ---------------------------------------------------------------------------
// GPIO INPUTS shown read-only on the dashboard.
// ---------------------------------------------------------------------------
struct InputPin {
  uint8_t     pin;
  const char* name;
  bool        pullup;     // enable internal pull-up
  bool        activeLow;  // true: LOW = "active"
};

static const InputPin INPUTS[] = {
  { 0, "BOOT_BUTTON", true, true },    // the BOOT button exists on DevKit boards
};
static const size_t INPUT_COUNT = sizeof(INPUTS) / sizeof(INPUTS[0]);
