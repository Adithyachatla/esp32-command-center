#pragma once
// ---------------------------------------------------------------------------
// JARVIS credentials - TEMPLATE (safe to commit, contains only placeholders).
//
// 1. Copy this file to include/secrets.h      (Windows: copy include\secrets.example.h include\secrets.h)
// 2. Put YOUR OWN values in secrets.h
// 3. secrets.h is listed in .gitignore - never commit it or paste it into issues.
//
// Do not leave the placeholder passwords in a device you actually use.
// ---------------------------------------------------------------------------

// Wi-Fi access point the ESP32 creates (password must be 8-63 characters)
#define JARVIS_AP_SSID       "JARVIS"
#define JARVIS_AP_PASSWORD   "CHANGE-ME-AP-PASS"

// Dashboard login (max 63 characters each)
#define JARVIS_LOGIN_USER    "admin"
#define JARVIS_LOGIN_PASS    "CHANGE-ME-LOGIN"
