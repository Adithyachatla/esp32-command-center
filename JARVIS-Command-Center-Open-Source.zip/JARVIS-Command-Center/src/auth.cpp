#include "auth.h"
#include "config.h"
#include <esp_system.h>

static_assert(MAX_SESSIONS <= 8, "MAX_SESSIONS must be <= 8");

namespace {

const char* COOKIE_NAME = "JARVIS_SID";
const size_t TOKEN_LEN = 32;  // hex chars (128 bit)

struct Session {
  bool     used;
  char     token[TOKEN_LEN + 1];
  uint32_t lastSeen;
};

struct Attempt {
  bool     used;
  uint32_t ip;
  uint8_t  fails;
  uint8_t  strikes;
  bool     locked;
  uint32_t lockUntil;
  uint32_t touched;
};

const uint8_t ATTEMPT_SLOTS = 6;
Session sessions[8];  // MAX_SESSIONS (<= 8) used
Attempt attempts[ATTEMPT_SLOTS];

// Compare in time independent of where the first mismatch is.
bool ctEqual(const String& a, const char* b) {
  const size_t lb = strlen(b);
  if (a.length() > 64) return false;
  uint8_t diff = (a.length() != lb) ? 1 : 0;
  for (size_t i = 0; i < 64; i++) {
    uint8_t x = i < a.length() ? (uint8_t)a[i] : 0;
    uint8_t y = i < lb ? (uint8_t)b[i] : 0;
    diff |= (x ^ y);
  }
  return diff == 0;
}

Attempt* findAttempt(uint32_t ip) {
  Attempt* oldest = &attempts[0];
  for (uint8_t i = 0; i < ATTEMPT_SLOTS; i++) {
    if (attempts[i].used && attempts[i].ip == ip) return &attempts[i];
    if (!attempts[i].used) { oldest = &attempts[i]; break; }
    if ((int32_t)(oldest->touched - attempts[i].touched) > 0) oldest = &attempts[i];
  }
  memset(oldest, 0, sizeof(Attempt));
  oldest->used = true;
  oldest->ip = ip;
  return oldest;
}

String newToken() {
  static const char* hex = "0123456789abcdef";
  char buf[TOKEN_LEN + 1];
  for (size_t i = 0; i < TOKEN_LEN; i += 8) {
    uint32_t r = esp_random();  // hardware RNG (true random while Wi-Fi is on)
    for (int n = 0; n < 8; n++) { buf[i + n] = hex[r & 0xF]; r >>= 4; }
  }
  buf[TOKEN_LEN] = 0;
  return String(buf);
}

String createSession() {
  uint32_t now = millis();
  Session* slot = nullptr;
  for (uint8_t i = 0; i < MAX_SESSIONS; i++) {
    if (!sessions[i].used || (now - sessions[i].lastSeen) > SESSION_IDLE_TIMEOUT_MS) {
      slot = &sessions[i];
      break;
    }
  }
  if (!slot) {  // all busy: replace the least recently used
    slot = &sessions[0];
    for (uint8_t i = 1; i < MAX_SESSIONS; i++)
      if ((now - sessions[i].lastSeen) > (now - slot->lastSeen)) slot = &sessions[i];
  }
  String t = newToken();
  strncpy(slot->token, t.c_str(), TOKEN_LEN);
  slot->token[TOKEN_LEN] = 0;
  slot->used = true;
  slot->lastSeen = now;
  return t;
}

// Extract our cookie value from the Cookie header. Returns empty on failure.
String tokenFromRequest(AsyncWebServerRequest* request) {
  if (!request->hasHeader("Cookie")) return String();
  String c = request->header("Cookie");
  String key = String(COOKIE_NAME) + "=";
  int p = c.indexOf(key);
  if (p < 0) return String();
  if (p > 0 && c[p - 1] != ' ' && c[p - 1] != ';') return String();
  p += key.length();
  String v = c.substring(p, p + TOKEN_LEN);
  if (v.length() != TOKEN_LEN) return String();
  return v;
}

Session* findSession(const String& token) {
  if (token.length() != TOKEN_LEN) return nullptr;
  for (uint8_t i = 0; i < MAX_SESSIONS; i++) {
    if (sessions[i].used && strcmp(sessions[i].token, token.c_str()) == 0)
      return &sessions[i];
  }
  return nullptr;
}

}  // namespace

namespace Auth {

void begin() {
  memset(sessions, 0, sizeof(sessions));
  memset(attempts, 0, sizeof(attempts));
}

Result login(uint32_t ip, const String& user, const String& pass,
             String& token, uint32_t& retrySeconds) {
  const uint32_t now = millis();
  Attempt* a = findAttempt(ip);
  a->touched = now;

  if (a->locked) {
    if ((int32_t)(a->lockUntil - now) > 0) {
      retrySeconds = (a->lockUntil - now + 999) / 1000;
      return Result::LOCKED;
    }
    a->locked = false;
  }

  // Evaluate both so timing does not reveal which one was wrong.
  const bool userOk = ctEqual(user, JARVIS_LOGIN_USER);
  const bool passOk = ctEqual(pass, JARVIS_LOGIN_PASS);

  if (userOk && passOk) {
    a->fails = 0;
    a->strikes = 0;
    token = createSession();
    return Result::OK;
  }

  a->fails++;
  if (a->fails >= LOGIN_MAX_FAILS) {
    a->fails = 0;
    if (a->strikes < 4) a->strikes++;
    uint32_t mult = 1UL << (a->strikes - 1);  // 1,2,4,8,8...
    if (mult > 8) mult = 8;
    a->locked = true;
    a->lockUntil = now + LOGIN_LOCK_MS * mult;
    retrySeconds = (LOGIN_LOCK_MS * mult) / 1000;
    Serial.printf("[AUTH] too many failures from %u.%u.%u.%u - locked %us\n",
                  ip & 255, (ip >> 8) & 255, (ip >> 16) & 255, (ip >> 24) & 255,
                  (unsigned)retrySeconds);
    return Result::LOCKED;
  }
  return Result::BAD;
}

uint8_t attemptsLeft(uint32_t ip) {
  Attempt* a = findAttempt(ip);
  return LOGIN_MAX_FAILS - a->fails;
}

bool check(AsyncWebServerRequest* request) {
  Session* s = findSession(tokenFromRequest(request));
  if (!s) return false;
  const uint32_t now = millis();
  if ((now - s->lastSeen) > SESSION_IDLE_TIMEOUT_MS) {
    s->used = false;
    return false;
  }
  s->lastSeen = now;
  return true;
}

void logout(AsyncWebServerRequest* request) {
  Session* s = findSession(tokenFromRequest(request));
  if (s) { s->used = false; memset(s->token, 0, sizeof(s->token)); }
}

String cookieHeader(const String& token) {
  return String(COOKIE_NAME) + "=" + token +
         "; Path=/; HttpOnly; SameSite=Strict; Max-Age=" +
         String(SESSION_IDLE_TIMEOUT_MS / 1000);
}

String clearCookieHeader() {
  return String(COOKIE_NAME) + "=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0";
}

}  // namespace Auth
