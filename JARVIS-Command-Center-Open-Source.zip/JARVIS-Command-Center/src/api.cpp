#include "api.h"
#include "auth.h"
#include "hardware.h"
#include "config.h"
#include <WiFi.h>
#include <LittleFS.h>
#include <esp_wifi.h>
#include <esp_timer.h>

namespace {

// ---------------------------------------------------------------- helpers
String jsonEscape(const String& in) {
  String out;
  out.reserve(in.length() + 8);
  for (size_t i = 0; i < in.length(); i++) {
    char c = in[i];
    if (c == '"' || c == '\\') { out += '\\'; out += c; }
    else if ((uint8_t)c < 0x20) { out += ' '; }
    else out += c;
  }
  return out;
}

void sendJson(AsyncWebServerRequest* r, int code, const String& body) {
  AsyncWebServerResponse* resp = r->beginResponse(code, "application/json", body);
  resp->addHeader("Cache-Control", "no-store");
  r->send(resp);
}

void sendErr(AsyncWebServerRequest* r, int code, const char* msg) {
  sendJson(r, code, String("{\"ok\":false,\"error\":\"") + msg + "\"}");
}

bool sameOrigin(AsyncWebServerRequest* r) {
  if (!r->hasHeader("Origin")) return true;   // same-origin fetches may omit it
  String o = r->header("Origin");
  int i = o.indexOf("://");
  if (i >= 0) o = o.substring(i + 3);
  return o == r->header("Host");
}

bool getParam(AsyncWebServerRequest* r, const char* key, String& out) {
  if (!r->hasParam(key, true)) return false;
  out = r->getParam(key, true)->value();
  return true;
}

// Guards. Each returns false after sending the error response.
bool requireAuth(AsyncWebServerRequest* r) {
  if (Auth::check(r)) return true;
  sendErr(r, 401, "UNAUTHORIZED");
  return false;
}
bool requireAuthPost(AsyncWebServerRequest* r) {
  if (!sameOrigin(r)) { sendErr(r, 403, "BAD_ORIGIN"); return false; }
  return requireAuth(r);
}

String macToString(const uint8_t* m) {
  char b[18];
  snprintf(b, sizeof(b), "%02X:%02X:%02X:%02X:%02X:%02X", m[0], m[1], m[2], m[3], m[4], m[5]);
  return String(b);
}

// ---------------------------------------------------------------- builders
String buildInfo() {
  String j;
  j.reserve(512);
  j += "{\"ok\":true";
  j += ",\"device\":\"" FW_NAME "\"";
  j += ",\"firmware\":\"" FW_VERSION "\"";
  j += ",\"chip\":\"" + jsonEscape(ESP.getChipModel()) + "\"";
  j += ",\"revision\":" + String(ESP.getChipRevision());
  j += ",\"cores\":" + String(ESP.getChipCores());
  j += ",\"cpuMHz\":" + String(ESP.getCpuFreqMHz());
  j += ",\"flashBytes\":" + String(ESP.getFlashChipSize());
  j += ",\"sketchBytes\":" + String(ESP.getSketchSize());
  j += ",\"sdk\":\"" + jsonEscape(ESP.getSdkVersion()) + "\"";
  j += ",\"mac\":\"" + WiFi.softAPmacAddress() + "\"";
  j += ",\"fsUsed\":" + String((unsigned)LittleFS.usedBytes());
  j += ",\"fsTotal\":" + String((unsigned)LittleFS.totalBytes());
  j += ",\"outputs\":" + String((unsigned)OUTPUT_COUNT);
  j += ",\"inputs\":" + String((unsigned)INPUT_COUNT);
  j += "}";
  return j;
}

String buildStatus() {
  String j;
  j.reserve(1400);
  j += "{\"ok\":true";
  j += ",\"uptime\":" + String((unsigned long)(esp_timer_get_time() / 1000000ULL));
  j += ",\"heap\":{\"free\":" + String(ESP.getFreeHeap()) +
       ",\"min\":" + String(ESP.getMinFreeHeap()) +
       ",\"maxBlock\":" + String(ESP.getMaxAllocHeap()) + "}";

  float t = Hardware::chipTemperatureC();
  j += ",\"tempC\":" + (isnan(t) ? String("null") : String(t, 1));

  // Wi-Fi (access point)
  j += ",\"wifi\":{\"mode\":\"AP\"";
  j += ",\"ssid\":\"" + jsonEscape(WiFi.softAPSSID()) + "\"";
  j += ",\"ip\":\"" + WiFi.softAPIP().toString() + "\"";
  j += ",\"mac\":\"" + WiFi.softAPmacAddress() + "\"";
  j += ",\"channel\":" + String(WiFi.channel());
  j += ",\"clients\":" + String(WiFi.softAPgetStationNum());
  j += ",\"maxClients\":" + String(JARVIS_AP_MAX_CLIENTS);
  j += ",\"txPower\":\"" + String(Hardware::txPowerName()) + "\"";
  j += ",\"txLevel\":" + String(Hardware::txPowerLevel());
  j += ",\"stations\":[";
  wifi_sta_list_t list;
  if (esp_wifi_ap_get_sta_list(&list) == ESP_OK) {
    for (int i = 0; i < list.num; i++) {
      if (i) j += ",";
      j += "{\"mac\":\"" + macToString(list.sta[i].mac) + "\",\"rssi\":" + String(list.sta[i].rssi) + "}";
    }
  }
  j += "]}";

  // Bluetooth
  j += ",\"bluetooth\":{";
  j += "\"classic\":{\"hardware\":true,\"firmware\":false}";
  j += ",\"ble\":{\"hardware\":true,\"firmware\":true";
  j += ",\"advertising\":" + String(Hardware::bleAdvertising() ? "true" : "false");
  j += ",\"name\":\"" BLE_DEVICE_NAME "\"";
  j += ",\"connections\":" + String(Hardware::bleConnections()) + "}}";

  // GPIO
  j += ",\"gpio\":{\"outputs\":[";
  for (size_t i = 0; i < OUTPUT_COUNT; i++) {
    if (i) j += ",";
    j += "{\"id\":" + String((unsigned)i);
    j += ",\"name\":\"" + jsonEscape(OUTPUTS[i].name) + "\"";
    j += ",\"pin\":" + String(OUTPUTS[i].pin);
    j += ",\"activeHigh\":" + String(OUTPUTS[i].activeHigh ? "true" : "false");
    j += ",\"blocked\":" + String(Hardware::outputBlocked(i) ? "true" : "false");
    j += ",\"on\":" + String(Hardware::outputIsOn(i) ? "true" : "false");
    j += ",\"level\":" + String(Hardware::outputLevelHigh(i) ? 1 : 0) + "}";
  }
  j += "],\"inputs\":[";
  for (size_t i = 0; i < INPUT_COUNT; i++) {
    if (i) j += ",";
    j += "{\"name\":\"" + jsonEscape(INPUTS[i].name) + "\"";
    j += ",\"pin\":" + String(INPUTS[i].pin);
    j += ",\"active\":" + String(Hardware::inputActive(i) ? "true" : "false") + "}";
  }
  j += "]}";

  // I2C
  const char* st = Hardware::i2cState() == Hardware::I2C_SCANNING ? "scanning"
                 : Hardware::i2cState() == Hardware::I2C_DONE ? "done" : "idle";
  j += ",\"i2c\":{\"state\":\"" + String(st) + "\",\"sda\":" + String(I2C_SDA) +
       ",\"scl\":" + String(I2C_SCL) + ",\"found\":[";
  for (uint8_t i = 0; i < Hardware::i2cFoundCount(); i++) {
    if (i) j += ",";
    j += String(Hardware::i2cFoundAddr(i));
  }
  j += "]}";

  j += "}";
  return j;
}

}  // namespace

// ---------------------------------------------------------------- routes
namespace Api {

void begin(AsyncWebServer& server, bool filesystemOk) {

  // ---- public ----
  server.on("/api/session", HTTP_GET, [](AsyncWebServerRequest* r) {
    String j = String("{\"ok\":true,\"authenticated\":") + (Auth::check(r) ? "true" : "false") +
               ",\"device\":\"" FW_NAME "\"}";
    sendJson(r, 200, j);
  });

  server.on("/api/login", HTTP_POST, [](AsyncWebServerRequest* r) {
    if (!sameOrigin(r)) { sendErr(r, 403, "BAD_ORIGIN"); return; }
    String user, pass;
    if (!getParam(r, "user", user) || !getParam(r, "pass", pass)) {
      sendErr(r, 400, "MISSING_FIELDS");
      return;
    }
    const uint32_t ip = (uint32_t)r->client()->remoteIP();
    String token;
    uint32_t retry = 0;
    Auth::Result res = Auth::login(ip, user, pass, token, retry);

    if (res == Auth::Result::OK) {
      AsyncWebServerResponse* resp = r->beginResponse(200, "application/json", "{\"ok\":true}");
      resp->addHeader("Cache-Control", "no-store");
      resp->addHeader("Set-Cookie", Auth::cookieHeader(token).c_str());
      r->send(resp);
      Serial.println("[AUTH] login OK");
    } else if (res == Auth::Result::LOCKED) {
      sendJson(r, 429, String("{\"ok\":false,\"error\":\"LOCKED\",\"retryAfter\":") + retry + "}");
    } else {
      Serial.println("[AUTH] login DENIED");
      sendJson(r, 401, String("{\"ok\":false,\"error\":\"ACCESS DENIED\",\"attemptsLeft\":") +
                        Auth::attemptsLeft(ip) + "}");
    }
  });

  // ---- protected ----
  server.on("/api/logout", HTTP_POST, [](AsyncWebServerRequest* r) {
    if (!sameOrigin(r)) { sendErr(r, 403, "BAD_ORIGIN"); return; }
    Auth::logout(r);
    AsyncWebServerResponse* resp = r->beginResponse(200, "application/json", "{\"ok\":true}");
    resp->addHeader("Set-Cookie", Auth::clearCookieHeader().c_str());
    r->send(resp);
  });

  server.on("/api/info", HTTP_GET, [](AsyncWebServerRequest* r) {
    if (!requireAuth(r)) return;
    sendJson(r, 200, buildInfo());
  });

  server.on("/api/status", HTTP_GET, [](AsyncWebServerRequest* r) {
    if (!requireAuth(r)) return;
    sendJson(r, 200, buildStatus());
  });

  server.on("/api/gpio", HTTP_POST, [](AsyncWebServerRequest* r) {
    if (!requireAuthPost(r)) return;
    String id, state;
    if (!getParam(r, "id", id) || !getParam(r, "state", state)) { sendErr(r, 400, "MISSING_FIELDS"); return; }
    long i = id.toInt();
    if (i < 0 || (size_t)i >= OUTPUT_COUNT || (id != "0" && i == 0)) { sendErr(r, 404, "NO_SUCH_OUTPUT"); return; }
    if (state != "1" && state != "0") { sendErr(r, 400, "BAD_STATE"); return; }
    if (!Hardware::setOutput((size_t)i, state == "1")) { sendErr(r, 409, "PIN_BLOCKED"); return; }
    sendJson(r, 200, String("{\"ok\":true,\"id\":") + i + ",\"on\":" +
                      (Hardware::outputIsOn((size_t)i) ? "true" : "false") + "}");
  });

  server.on("/api/bluetooth", HTTP_POST, [](AsyncWebServerRequest* r) {
    if (!requireAuthPost(r)) return;
    String state;
    if (!getParam(r, "state", state) || (state != "1" && state != "0")) { sendErr(r, 400, "BAD_STATE"); return; }
    Hardware::requestBle(state == "1");   // executed from loop(), not here
    sendJson(r, 202, "{\"ok\":true,\"pending\":true}");
  });

  server.on("/api/wifi/txpower", HTTP_POST, [](AsyncWebServerRequest* r) {
    if (!requireAuthPost(r)) return;
    String level;
    if (!getParam(r, "level", level) || level.length() != 1 || level[0] < '0' || level[0] > '2') {
      sendErr(r, 400, "BAD_LEVEL");
      return;
    }
    if (!Hardware::setTxPowerLevel((uint8_t)(level[0] - '0'))) { sendErr(r, 500, "TXPOWER_FAILED"); return; }
    sendJson(r, 200, "{\"ok\":true}");
  });

  server.on("/api/i2c/scan", HTTP_POST, [](AsyncWebServerRequest* r) {
    if (!requireAuthPost(r)) return;
    Hardware::requestI2cScan();
    sendJson(r, 202, "{\"ok\":true,\"pending\":true}");
  });

  server.on("/api/reboot", HTTP_POST, [](AsyncWebServerRequest* r) {
    if (!requireAuthPost(r)) return;
    Hardware::requestReboot(800);
    sendJson(r, 200, "{\"ok\":true}");
  });

  // ---- frontend ----
  if (filesystemOk) {
    // Fonts get an explicit MIME type (not every library version knows woff2).
    server.on("/fonts/*", HTTP_GET, [](AsyncWebServerRequest* r) {
      String path = r->url();
      if (path.indexOf("..") >= 0 || !path.endsWith(".woff2") || !LittleFS.exists(path)) {
        r->send(404, "text/plain", "NOT FOUND");
        return;
      }
      AsyncWebServerResponse* resp = r->beginResponse(LittleFS, path, "font/woff2");
      resp->addHeader("Cache-Control", "public, max-age=86400");
      r->send(resp);
    });
    server.serveStatic("/", LittleFS, "/")
          .setDefaultFile("index.html")
          .setCacheControl("no-cache");
  } else {
    server.on("/", HTTP_GET, [](AsyncWebServerRequest* r) {
      r->send(200, "text/plain",
              "JARVIS: filesystem not mounted.\n"
              "Run: PlatformIO > Upload Filesystem Image, then reset the board.\n");
    });
  }

  server.onNotFound([](AsyncWebServerRequest* r) {
    if (r->url().startsWith("/api/")) sendErr(r, 404, "NOT_FOUND");
    else r->send(404, "text/plain", "404 NOT FOUND");
  });
}

}  // namespace Api
