#pragma once
#include <Arduino.h>
#include <ESPAsyncWebServer.h>

// Session-cookie authentication with per-IP lockout.
namespace Auth {

enum class Result { OK, BAD, LOCKED };

void begin();

// Verify credentials. On OK, 'token' holds a new session token.
// On LOCKED, 'retrySeconds' says how long until the next try is allowed.
Result login(uint32_t ip, const String& user, const String& pass,
             String& token, uint32_t& retrySeconds);

uint8_t attemptsLeft(uint32_t ip);

// True if the request carries a valid, non-expired session cookie.
// A successful check refreshes the idle timer.
bool check(AsyncWebServerRequest* request);

// Invalidate the session carried by this request (if any).
void logout(AsyncWebServerRequest* request);

// Value for the Set-Cookie header
String cookieHeader(const String& token);
String clearCookieHeader();

}  // namespace Auth
