#pragma once
#include <Arduino.h>

// All direct hardware access lives here: GPIO, BLE, I2C scan, radio power,
// deferred actions that must not run inside the web-server task.
namespace Hardware {

void begin();
void service();   // call from loop()

// ---- GPIO ----
bool isSafeOutputPin(uint8_t pin);
bool outputBlocked(size_t i);
bool outputLevelHigh(size_t i);   // real pin level read back from the chip
bool outputIsOn(size_t i);        // level interpreted with activeHigh
bool setOutput(size_t i, bool on);
bool inputActive(size_t i);

// ---- Bluetooth Low Energy ----
void requestBle(bool enable);     // applied from loop()
bool bleAdvertising();
uint8_t bleConnections();

// ---- Wi-Fi radio ----
bool setTxPowerLevel(uint8_t level);  // 0=LOW 1=MED 2=HIGH
uint8_t txPowerLevel();
const char* txPowerName();

// ---- I2C scan (runs from loop(), result polled via /api/status) ----
enum I2cState : uint8_t { I2C_IDLE = 0, I2C_SCANNING = 1, I2C_DONE = 2 };
void requestI2cScan();
I2cState i2cState();
uint8_t i2cFoundCount();
uint8_t i2cFoundAddr(uint8_t idx);

// ---- misc ----
void requestReboot(uint32_t delayMs);
float chipTemperatureC();         // NAN if unavailable

}  // namespace Hardware
