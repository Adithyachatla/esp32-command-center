// JARVIS - ESP32 Command Center
// main.cpp: boot sequence only (filesystem, Wi-Fi access point, web server).
// Routes/auth live in api.cpp + auth.cpp, hardware access in hardware.cpp.

#include <Arduino.h>
#include <WiFi.h>
#include <LittleFS.h>
#include <ESPAsyncWebServer.h>

#include "config.h"
#include "auth.h"
#include "hardware.h"
#include "api.h"

AsyncWebServer server(80);
static bool fsOk = false;

static void listFiles(const char* dir, uint8_t depth = 0) {
  File root = LittleFS.open(dir);
  if (!root || !root.isDirectory()) return;
  File f = root.openNextFile();
  while (f) {
    for (uint8_t i = 0; i < depth; i++) Serial.print("  ");
    if (f.isDirectory()) {
      Serial.printf("  %s/\n", f.name());
      listFiles(f.path(), depth + 1);
    } else {
      Serial.printf("  %s (%u bytes)\n", f.name(), (unsigned)f.size());
    }
    f = root.openNextFile();
  }
}

void setup() {
  Serial.begin(115200);
  delay(300);
  Serial.println();
  Serial.println("==================================================");
  Serial.println(" JARVIS - Just A Rather Very Intelligent System");
  Serial.println(" firmware " FW_VERSION);
  Serial.println("==================================================");
  Serial.printf("[SYS] chip %s rev %d, %d core(s) @ %u MHz, flash %u KB\n",
                ESP.getChipModel(), ESP.getChipRevision(), ESP.getChipCores(),
                ESP.getCpuFreqMHz(), (unsigned)(ESP.getFlashChipSize() / 1024));

  // 1. Filesystem (do NOT auto-format: a failed mount means "upload the FS image")
  fsOk = LittleFS.begin(false);
  if (fsOk) {
    Serial.printf("[FS] LittleFS mounted (%u / %u bytes used)\n",
                  (unsigned)LittleFS.usedBytes(), (unsigned)LittleFS.totalBytes());
    listFiles("/");
    if (!LittleFS.exists("/index.html"))
      Serial.println("[FS] WARNING: /index.html missing - upload the filesystem image");
  } else {
    Serial.println("[FS] MOUNT FAILED - run 'Upload Filesystem Image' in PlatformIO");
  }

  // 2. Hardware + auth state
  Hardware::begin();
  Auth::begin();

  // 3. Wi-Fi access point
  WiFi.mode(WIFI_AP);
  WiFi.setSleep(false);
  bool apOk = WiFi.softAP(JARVIS_AP_SSID, JARVIS_AP_PASSWORD, JARVIS_AP_CHANNEL, JARVIS_AP_HIDDEN, JARVIS_AP_MAX_CLIENTS);
  if (!apOk) {
    Serial.println("[WIFI] softAP FAILED (is JARVIS_AP_PASSWORD 8-63 characters?)");
  } else {
    Hardware::setTxPowerLevel(2);
    Serial.printf("[WIFI] AP \"%s\" up on channel %u\n", JARVIS_AP_SSID, JARVIS_AP_CHANNEL);
    Serial.printf("[WIFI] open http://%s/\n", WiFi.softAPIP().toString().c_str());
  }

  // 4. Web server
  Api::begin(server, fsOk);
  server.begin();
  Serial.println("[HTTP] server started on port 80");
  Serial.println("[SYS] READY");
}

void loop() {
  Hardware::service();
  delay(10);
}
