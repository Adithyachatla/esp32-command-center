#pragma once
#include <ESPAsyncWebServer.h>

namespace Api {
// Registers all /api routes, static file serving and the 404 handler.
// Must be called before server.begin().
void begin(AsyncWebServer& server, bool filesystemOk);
}
