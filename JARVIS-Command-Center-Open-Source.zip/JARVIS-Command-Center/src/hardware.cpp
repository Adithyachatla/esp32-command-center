#include "hardware.h"
#include "config.h"
#include <WiFi.h>
#include <Wire.h>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>

static_assert(OUTPUT_COUNT <= 8, "JARVIS supports at most 8 configured outputs");

namespace {

bool outBlocked[8];          // OUTPUT_COUNT must be <= 8
const uint8_t MAX_I2C_FOUND = 24;

// BLE
volatile int8_t bleRequest = -1;   // -1 none, 0 stop, 1 start
bool bleOn = false;
BLEServer* bleServer = nullptr;

// I2C
volatile bool i2cRequest = false;
volatile Hardware::I2cState i2cSt = Hardware::I2C_IDLE;
uint8_t i2cFound[MAX_I2C_FOUND];
uint8_t i2cCount = 0;

// radio
uint8_t txLevel = 2;

// reboot
volatile uint32_t rebootAt = 0;
volatile bool rebootPending = false;

void startBle() {
  if (bleOn) return;
  BLEDevice::init(BLE_DEVICE_NAME);
  bleServer = BLEDevice::createServer();
  BLEAdvertising* adv = BLEDevice::getAdvertising();
  adv->setScanResponse(true);
  BLEDevice::startAdvertising();
  bleOn = true;
  Serial.println("[BLE] advertising started");
}

void stopBle() {
  if (!bleOn) return;
  BLEDevice::getAdvertising()->stop();
  bleServer = nullptr;
  // deinit(false): keep controller memory so BLE can be started again later
  BLEDevice::deinit(false);
  bleOn = false;
  Serial.println("[BLE] stopped");
}

void doI2cScan() {
  i2cCount = 0;
  Wire.begin(I2C_SDA, I2C_SCL);
  for (uint8_t addr = 1; addr < 127; addr++) {
    Wire.beginTransmission(addr);
    if (Wire.endTransmission() == 0 && i2cCount < MAX_I2C_FOUND) {
      i2cFound[i2cCount++] = addr;
    }
  }
  Wire.end();
  Serial.printf("[I2C] scan done, %u device(s)\n", i2cCount);
}

}  // namespace

namespace Hardware {

bool isSafeOutputPin(uint8_t pin) {
  static const uint8_t ok[] = {2, 4, 5, 13, 14, 15, 16, 17, 18, 19, 23, 25, 26, 27, 32, 33};
  for (size_t i = 0; i < sizeof(ok); i++) if (ok[i] == pin) return true;
  return false;
}

void begin() {
  for (size_t i = 0; i < OUTPUT_COUNT && i < 8; i++) {
    const OutputPin& o = OUTPUTS[i];
    if (!isSafeOutputPin(o.pin)) {
      outBlocked[i] = true;
      Serial.printf("[GPIO] BLOCKED unsafe output pin %u (%s)\n", o.pin, o.name);
      continue;
    }
    // set the level BEFORE switching to output to avoid a glitch
    digitalWrite(o.pin, (o.initialOn == o.activeHigh) ? HIGH : LOW);
    pinMode(o.pin, OUTPUT);
    digitalWrite(o.pin, (o.initialOn == o.activeHigh) ? HIGH : LOW);
    Serial.printf("[GPIO] output %-12s GPIO%-2u ready\n", o.name, o.pin);
  }
  for (size_t i = 0; i < INPUT_COUNT; i++) {
    pinMode(INPUTS[i].pin, INPUTS[i].pullup ? INPUT_PULLUP : INPUT);
    Serial.printf("[GPIO] input  %-12s GPIO%-2u ready\n", INPUTS[i].name, INPUTS[i].pin);
  }
}

void service() {
  int8_t br = bleRequest;
  if (br >= 0) {
    bleRequest = -1;
    if (br == 1) startBle(); else stopBle();
  }
  if (i2cRequest) {
    i2cRequest = false;
    i2cSt = I2C_SCANNING;
    doI2cScan();
    i2cSt = I2C_DONE;
  }
  if (rebootPending && (int32_t)(millis() - rebootAt) >= 0) {
    Serial.println("[SYS] rebooting");
    delay(50);
    ESP.restart();
  }
}

// ---- GPIO ----
bool outputBlocked(size_t i) { return i < 8 ? outBlocked[i] : true; }

bool outputLevelHigh(size_t i) {
  if (i >= OUTPUT_COUNT || outBlocked[i]) return false;
  return digitalRead(OUTPUTS[i].pin) == HIGH;
}

bool outputIsOn(size_t i) {
  if (i >= OUTPUT_COUNT || outBlocked[i]) return false;
  return outputLevelHigh(i) == OUTPUTS[i].activeHigh;
}

bool setOutput(size_t i, bool on) {
  if (i >= OUTPUT_COUNT || outBlocked[i]) return false;
  digitalWrite(OUTPUTS[i].pin, (on == OUTPUTS[i].activeHigh) ? HIGH : LOW);
  Serial.printf("[GPIO] %s -> %s\n", OUTPUTS[i].name, on ? "ON" : "OFF");
  return true;
}

bool inputActive(size_t i) {
  if (i >= INPUT_COUNT) return false;
  bool high = digitalRead(INPUTS[i].pin) == HIGH;
  return INPUTS[i].activeLow ? !high : high;
}

// ---- BLE ----
void requestBle(bool enable) { bleRequest = enable ? 1 : 0; }
bool bleAdvertising() { return bleOn && bleRequest != 0; }
uint8_t bleConnections() {
  if (!bleOn || !bleServer) return 0;
  return (uint8_t)bleServer->getConnectedCount();
}

// ---- Wi-Fi radio ----
bool setTxPowerLevel(uint8_t level) {
  wifi_power_t p;
  switch (level) {
    case 0: p = WIFI_POWER_8_5dBm; break;
    case 1: p = WIFI_POWER_13dBm; break;
    case 2: p = WIFI_POWER_19_5dBm; break;
    default: return false;
  }
  if (!WiFi.setTxPower(p)) return false;
  txLevel = level;
  Serial.printf("[WIFI] TX power level %u\n", level);
  return true;
}
uint8_t txPowerLevel() { return txLevel; }
const char* txPowerName() {
  static const char* names[] = {"LOW", "MED", "HIGH"};
  return names[txLevel > 2 ? 2 : txLevel];
}

// ---- I2C ----
void requestI2cScan() { if (i2cSt != I2C_SCANNING) { i2cSt = I2C_SCANNING; i2cRequest = true; } }
I2cState i2cState() { return i2cSt; }
uint8_t i2cFoundCount() { return i2cCount; }
uint8_t i2cFoundAddr(uint8_t idx) { return idx < i2cCount ? i2cFound[idx] : 0; }

// ---- misc ----
void requestReboot(uint32_t delayMs) {
  rebootAt = millis() + delayMs;
  rebootPending = true;
}

float chipTemperatureC() {
  float t = temperatureRead();
  if (isnan(t) || t < -40 || t > 150) return NAN;
  return t;
}

}  // namespace Hardware
