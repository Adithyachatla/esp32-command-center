/* ==========================================================================
   JARVIS // ESP32 COMMAND CENTER  -  frontend logic
   Flow:  LOGIN -> ACCESS GRANTED -> ESP32 BOOT -> COMMAND CENTER
   No credentials or tokens are ever stored in the browser: the session
   lives in an HttpOnly cookie that only the ESP32 can read.
   ========================================================================== */
(() => {
'use strict';

const $  = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

function h(tag, props, ...kids) {
  const e = document.createElement(tag);
  if (props) for (const k of Object.keys(props)) {
    if (k === 'class') e.className = props[k];
    else if (k === 'text') e.textContent = props[k];
    else if (k.startsWith('data-')) e.setAttribute(k, props[k]);
    else e[k] = props[k];
  }
  for (const kid of kids) if (kid != null) e.append(kid);
  return e;
}
const pad2 = (n) => String(n).padStart(2, '0');
const kb = (b) => (b / 1024).toFixed(b > 10240 ? 0 : 1) + ' KB';
function fmtUptime(s) {
  const d = Math.floor(s / 86400), hh = Math.floor((s % 86400) / 3600), m = Math.floor((s % 3600) / 60), ss = s % 60;
  return (d ? d + 'd ' : '') + pad2(hh) + ':' + pad2(m) + ':' + pad2(ss);
}

/* ------------------------------------------------------------------ API */
async function api(path, opts = {}) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), opts.timeout || 6000);
  const init = { method: opts.method || 'GET', credentials: 'same-origin', signal: ctrl.signal, headers: {} };
  if (opts.form || init.method === 'POST') {
    init.method = 'POST';
    init.headers['Content-Type'] = 'application/x-www-form-urlencoded';
    init.body = new URLSearchParams(opts.form || {}).toString();
  }
  let res;
  try { res = await fetch(path, init); }
  catch (e) { throw Object.assign(new Error('NO LINK'), { net: true }); }
  finally { clearTimeout(timer); }
  let data = null;
  try { data = await res.json(); } catch (_) { /* not json */ }
  if (res.status === 401 && path !== '/api/login' && path !== '/api/session') sessionLost('SESSION EXPIRED');
  return { status: res.status, ok: res.ok, data };
}

/* -------------------------------------------------------------- screens */
let current = null;
const hooks = { login: [], dash: [] };
async function show(name) {
  const next = $('#screen-' + name);
  if (current === next) return;
  if (current) {
    current.classList.add('leaving');
    await sleep(reduced ? 0 : 270);
    current.classList.remove('leaving', 'active');
  }
  next.classList.add('active');
  document.body.dataset.screen = name;
  current = next;
  window.scrollTo(0, 0);
  login.active = (name === 'login');
  if (name === 'login') login.startFx();
}

/* ======================================================================
   SCREEN 2 : LOGIN
   ====================================================================== */
const login = {
  active: false, busy: false, locked: false, raf: 0, lines: [], lockTimer: 0,
  startFx() { cancelAnimationFrame(this.raf); const loop = (t) => { if (!this.active) return; drawTunnel(t); drawSkull(t); this.raf = requestAnimationFrame(loop); }; this.raf = requestAnimationFrame(loop); },
};

const SKULL_HALF = [
  '..........#####', '......#########', '....###########', '...############', '..#############',
  '..#############', '.##############', '.##############', '.##############', '.####....######',
  '.###......#####', '.###......#####', '.###......#####', '.####....######', '..#############',
  '..############.', '...##########..', '...############', '....###########', '....###########',
  '....##.##.##.##', '....##.##.##.##', '.....#########.', '......#########',
];
const SKULL = SKULL_HALF.map((r) => r + r.split('').reverse().join(''));

function fitCanvas(cv) {
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  const w = cv.clientWidth, hgt = cv.clientHeight;
  if (cv.width !== Math.round(w * dpr) || cv.height !== Math.round(hgt * dpr)) { cv.width = Math.round(w * dpr); cv.height = Math.round(hgt * dpr); }
  const ctx = cv.getContext('2d');
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  return { ctx, w, h: hgt };
}

function drawTunnel(t) {
  const { ctx, w, h: hh } = fitCanvas($('#tunnel'));
  ctx.clearRect(0, 0, w, hh);
  const cx = w / 2, cy = hh / 2;
  const iw = w * 0.34, ih = hh * 0.40;          // inner (far) rectangle
  const ow = w * 0.95, oh = hh * 0.95;          // outer (near) rectangle (beyond view)
  ctx.lineWidth = 1.4; ctx.strokeStyle = '#3dff72'; ctx.shadowColor = 'rgba(61,255,114,.7)'; ctx.shadowBlur = 5;
  // radial lines
  const pts = [];
  for (const a of [-1, -0.5, 0, 0.5, 1]) { pts.push([a, -1], [a, 1]); }
  for (const b of [-0.5, 0, 0.5]) { pts.push([-1, b], [1, b]); }
  ctx.globalAlpha = .75;
  ctx.beginPath();
  for (const [a, b] of pts) { ctx.moveTo(cx + a * iw / 2, cy + b * ih / 2); ctx.lineTo(cx + a * ow, cy + b * oh); }
  ctx.stroke();
  // rings travelling toward the viewer
  const N = 8, phase = reduced ? 0 : ((t || 0) / 5200) % 1;
  for (let k = 0; k < N; k++) {
    const u = (k + phase) / N, e = Math.pow(u, 2.1);
    const rw = iw / 2 + (ow - iw / 2) * e, rh = ih / 2 + (oh - ih / 2) * e;
    ctx.globalAlpha = 0.35 + 0.65 * (1 - Math.abs(u - .35));
    ctx.strokeRect(cx - rw, cy - rh, rw * 2, rh * 2);
  }
  ctx.globalAlpha = 1;
  ctx.lineWidth = 2; ctx.strokeRect(cx - iw / 2, cy - ih / 2, iw, ih);
}

function drawSkull(t) {
  const { ctx, w, h: hh } = fitCanvas($('#skull'));
  ctx.clearRect(0, 0, w, hh);
  const cols = SKULL[0].length, rows = SKULL.length;
  const cell = Math.min((w * 0.40) / cols, (hh * 0.62) / rows);
  const ox = (w - cell * cols) / 2, oy = (hh - cell * rows) / 2 - hh * 0.02;
  const dot = cell * 0.78, off = (cell - dot) / 2;
  ctx.shadowColor = 'rgba(61,255,114,.9)'; ctx.shadowBlur = cell * .7;
  const ts = (t || 0) / 1000;
  for (let r = 0; r < rows; r++) {
    const scan = reduced ? 1 : 0.78 + 0.22 * Math.sin(ts * 3 - r * 0.55);
    for (let c = 0; c < cols; c++) {
      if (SKULL[r][c] !== '#') continue;
      const edge = (r === 0 || SKULL[r - 1][c] !== '#' || c === 0 || SKULL[r][c - 1] !== '#' || c === cols - 1 || SKULL[r][c + 1] !== '#');
      ctx.fillStyle = edge ? '#b9ffcb' : '#3dff72';
      ctx.globalAlpha = scan * (edge ? 1 : 0.88);
      ctx.fillRect(ox + c * cell + off, oy + r * cell + off, dot, dot);
    }
  }
  ctx.globalAlpha = 1;
}

/* login log box */
function logSet(key, text, state) {
  const i = login.lines.findIndex((l) => l.key === key);
  const line = { key, text, state: state || '' };
  if (i >= 0) login.lines[i] = line; else login.lines.push(line);
  if (login.lines.length > 5) login.lines.shift();
  const ul = $('#login-log');
  ul.replaceChildren(...login.lines.map((l) => {
    const li = h('li', { class: l.state });
    li.append(l.key.padEnd(5, ' ').replace(/ /g, ' ') + '...... ', h('em', { text: l.text }));
    return li;
  }));
}
const setLed = (id, mode) => { const e = $('#' + id); e.className = 'led' + (mode ? ' ' + mode : ''); };
function setBtn(label, disabled, cls) {
  const b = $('#btn-login'); b.textContent = label; b.disabled = !!disabled; b.className = 'lf-btn' + (cls ? ' ' + cls : '');
}

function loginDenied(left) {
  logSet('AUTH', 'ACCESS DENIED', 'bad');
  if (typeof left === 'number') logSet('TRIES', left + ' LEFT', left <= 1 ? 'bad' : '');
  setLed('led-auth', 'warn');
  setTimeout(() => setLed('led-auth', ''), 1400);
  const f = $('.login-frame'); f.classList.remove('shake'); void f.offsetWidth; f.classList.add('shake');
  $('#in-pass').value = '';
  $('#in-pass').focus();
}

function loginLock(seconds) {
  login.locked = true;
  setLed('led-lock', 'warn'); setLed('led-auth', '');
  logSet('AUTH', 'LOCKED OUT', 'bad');
  let left = seconds;
  clearInterval(login.lockTimer);
  const tick = () => {
    if (left <= 0) {
      clearInterval(login.lockTimer); login.locked = false;
      setLed('led-lock', ''); logSet('AUTH', 'STANDBY'); logSet('TRIES', 'RESET');
      setBtn('[ AUTHENTICATE ]', false); return;
    }
    setBtn('[ LOCKED ' + left + 's ]', true, 'locked'); left--;
  };
  tick(); login.lockTimer = setInterval(tick, 1000);
}

async function onLoginSubmit(ev) {
  ev.preventDefault();
  if (login.busy || login.locked) return;
  const user = $('#in-user').value, pass = $('#in-pass').value;
  if (!user || !pass) { logSet('AUTH', 'EMPTY FIELD', 'bad'); return; }
  login.busy = true;
  setBtn('[ VERIFYING... ]', true); setLed('led-auth', 'warn'); logSet('AUTH', 'VERIFYING', 'blink');
  $('#in-pass').value = '';                          // never keep the password in the DOM
  try {
    const r = await api('/api/login', { form: { user, pass } });
    setLed('led-link', 'on');
    if (r.ok && r.data && r.data.ok) {
      setLed('led-auth', 'on'); logSet('AUTH', 'ACCESS OK');
      $('#in-user').value = '';
      await sleep(350);
      await runSequence();
      return;
    }
    if (r.status === 429) loginLock((r.data && r.data.retryAfter) || 60);
    else if (r.status === 401) loginDenied(r.data && r.data.attemptsLeft);
    else { logSet('AUTH', 'ERROR ' + r.status, 'bad'); setLed('led-auth', ''); }
  } catch (e) {
    setLed('led-link', 'warn'); setLed('led-auth', '');
    logSet('LINK', 'FAULT', 'bad'); logSet('AUTH', 'NO RESPONSE', 'bad');
  } finally {
    login.busy = false;
    if (!login.locked) setBtn('[ AUTHENTICATE ]', false);
  }
}

/* ======================================================================
   SCREEN 3 : ACCESS GRANTED   ->   SCREEN 4 : BOOT   ->   SCREEN 1
   ====================================================================== */
let boot = { info: null, status: null };

function fillNoise() {
  const hex = () => Math.floor(Math.random() * 65536).toString(16).padStart(4, '0').toUpperCase();
  const rows = [];
  for (let i = 0; i < 26; i++) rows.push(Array.from({ length: 22 }, hex).join(' '));
  $('#ag-noise').textContent = rows.join('\n');
}

async function runSequence() {
  fillNoise();
  await show('granted');
  const pre = Promise.all([api('/api/info').catch(() => null), api('/api/status').catch(() => null)])
    .then(([i, s]) => { boot.info = i && i.ok ? i.data : null; boot.status = s && s.ok ? s.data : null; });
  await sleep(reduced ? 800 : 2600);
  await pre;
  await show('boot');
  await runBoot();
  await show('dash');
  dash.start();
}

/* ---- ESP32 board drawing (after reference #4) ---- */
const PIN_L = ['3V3','CLK','SD0','SD1','D0','D15','D2','D4','RX2','TX2','D5','D18','D19','D21','RX0','TX0','D22','D23'];
const PIN_R = ['VIN','GND','CMD','SD3','SD2','D13','D12','D14','D27','D26','D25','D33','D32','D35','D34','VN','VP','EN'];

function buildBoard() {
  const NS = 'http://www.w3.org/2000/svg';
  const py = (i) => 142 + i * 34.9;
  let s = '';
  const L = (cls, inner) => inner; // readability
  // outline + mounting holes
  s += '<g id="g-outline"><rect class="ln" x="1" y="1" width="402" height="814" rx="28"/>' +
       '<circle class="ln" cx="26" cy="38" r="15"/><circle class="ln" cx="378" cy="38" r="15"/>' +
       '<circle class="ln" cx="26" cy="790" r="15"/><circle class="ln" cx="378" cy="790" r="15"/></g>';
  // USB-C + buttons
  s += '<g id="g-usb"><path class="ln" d="M144 -2 H264 V84 Q264 96 252 96 H156 Q144 96 144 84 Z"/>' +
       '<rect class="ln thin" x="156" y="10" width="96" height="70" rx="6"/>' +
       '<rect class="ln" x="172" y="40" width="64" height="16" rx="8"/>';
  for (let i = 0; i < 8; i++) s += `<rect class="ln thin" x="${158 + i * 12}" y="100" width="7" height="12"/>`;
  s += '</g>';
  s += '<g id="g-btn"><rect class="ln" x="66" y="16" width="38" height="62" rx="3"/><rect class="ln thin" x="74" y="28" width="22" height="38"/>' +
       '<rect class="ln" x="291" y="16" width="38" height="62" rx="3"/><rect class="ln thin" x="299" y="28" width="22" height="38"/></g>';
  // header pads under USB
  s += '<g id="g-pads">';
  for (let i = 0; i < 5; i++) s += `<rect class="ln thin" x="${64 + i * 19}" y="104" width="11" height="16"/>`;
  for (let i = 0; i < 6; i++) s += `<rect class="ln thin" x="${196 + i * 19}" y="104" width="11" height="16"/>`;
  s += '</g>';
  // QFN + regulator
  s += '<g id="g-ic"><rect class="ln fillable" id="qfn" x="76" y="150" width="72" height="72"/><rect class="ln thin" x="94" y="168" width="36" height="36"/>';
  for (let i = 0; i < 8; i++) {
    const o = 82 + i * 8;
    s += `<line class="ln thin" x1="${o}" y1="144" x2="${o}" y2="150"/><line class="ln thin" x1="${o}" y1="222" x2="${o}" y2="228"/>` +
         `<line class="ln thin" x1="70" y1="${o + 68}" x2="76" y2="${o + 68}"/><line class="ln thin" x1="148" y1="${o + 68}" x2="154" y2="${o + 68}"/>`;
  }
  s += '<rect class="ln" x="206" y="154" width="34" height="16"/><rect class="ln" x="206" y="184" width="34" height="16"/><rect class="ln" x="206" y="214" width="34" height="16"/>' +
       '<rect class="ln fillable" id="reg" x="246" y="140" width="64" height="104"/><line class="ln thin" x1="246" y1="180" x2="310" y2="180"/></g>';
  // passives
  s += '<g id="g-pass">';
  for (const [x, y, w, hh] of [[68,252,30,42],[152,250,24,34],[184,250,24,34],[218,246,34,22],[262,250,40,32]])
    s += `<rect class="ln" x="${x}" y="${y}" width="${w}" height="${hh}"/><line class="ln thin" x1="${x + w / 2}" y1="${y}" x2="${x + w / 2}" y2="${y + hh}"/>`;
  for (let i = 0; i < 10; i++) s += `<rect class="ln" x="${64 + i * 21}" y="318" width="16" height="40"/><line class="ln thin" x1="${64 + i * 21}" y1="338" x2="${80 + i * 21}" y2="338"/>`;
  s += '<rect class="ln" x="278" y="318" width="22" height="40"/><rect class="ln" x="306" y="318" width="22" height="40"/></g>';
  // traces
  s += '<g id="g-trace">' +
       '<path class="ln thin" d="M76 222 C 58 262 50 300 62 340"/><path class="ln thin" d="M148 186 H196 V250"/>' +
       '<path class="ln thin" d="M110 358 V420 L150 456"/><path class="ln thin" d="M250 358 V410 L214 456"/>' +
       '<path class="ln thin" d="M300 244 L330 280 V420 L304 456"/><path class="ln thin" d="M40 150 C 56 190 52 230 70 258"/>' +
       '<path class="ln thin" d="M368 140 C 346 200 350 300 330 330"/><path class="ln thin" d="M180 358 V430 L190 456"/></g>';
  // module (drawn rotated like the reference: text upside-down)
  s += '<g id="g-mod"><rect class="ln fillable" id="module" x="86" y="457" width="238" height="260"/><rect class="ln thin" x="94" y="465" width="222" height="244"/>';
  for (let i = 0; i < 14; i++) s += `<rect class="ln thin" x="68" y="${464 + i * 18}" width="18" height="10"/><rect class="ln thin" x="324" y="${464 + i * 18}" width="18" height="10"/>`;
  s += '<circle class="ln thin" cx="284" cy="490" r="5"/>' +
       '<g transform="rotate(180 205 587)">' +
       '<text class="show-late" x="216" y="652" text-anchor="middle" font-size="9.5">FCC ID:2AC7Z-ESPWROOM32</text>' +
       '<text class="show-late" x="250" y="616" text-anchor="middle" font-size="9.5">211-161007</text>' +
       '<text class="show-late" x="205" y="530" text-anchor="middle" font-size="15">ESP-WROOM-32</text>' +
       '<rect class="ln thin" x="170" y="590" width="26" height="22"/><text class="show-late" x="183" y="606" text-anchor="middle" font-size="12">R</text>' +
       '<circle class="ln thin" cx="262" cy="604" r="22"/><circle class="ln thin" cx="262" cy="604" r="14"/>' +
       '<circle class="ln thin" cx="214" cy="560" r="16"/><text class="show-late" x="214" y="565" text-anchor="middle" font-size="12">CE</text>' +
       '<rect class="ln thin" x="296" y="568" width="40" height="28" rx="8"/><path class="ln thin" d="M306 584 Q316 572 326 584 M310 588 Q316 581 322 588"/>' +
       '</g></g>';
  // antenna (meander)
  s += '<g id="g-ant"><path class="ln" d="M118 806 V742 H150 V796 H182 V742 H214 V796 H246 V742 H278 V806"/>' +
       '<path class="ln thin" d="M118 806 H112 V730 H286 V806 H278"/><rect class="ln thin" x="104" y="722" width="190" height="90"/></g>';
  // header pins + labels
  s += '<g id="g-pins">';
  s += '<rect class="ln" x="11" y="101" width="14" height="14"/><rect class="ln" x="379" y="101" width="14" height="14"/>';
  for (let i = 0; i < 18; i++) {
    s += `<circle class="pin" data-i="${i}" data-s="L" cx="18" cy="${py(i).toFixed(1)}" r="9.5"/><circle class="pin" data-i="${i}" data-s="R" cx="386" cy="${py(i).toFixed(1)}" r="9.5"/>`;
  }
  s += '</g><g id="g-labels">';
  for (let i = 0; i < 18; i++) {
    s += `<text transform="translate(33 ${py(i).toFixed(1)}) rotate(90)" text-anchor="middle">${PIN_L[i]}</text>` +
         `<text transform="translate(355 ${py(i).toFixed(1)}) rotate(90)" text-anchor="middle">${PIN_R[i]}</text>`;
  }
  s += '<text transform="translate(116 47) rotate(90)" text-anchor="middle">BOOT</text><text transform="translate(274 47) rotate(90)" text-anchor="middle">EN</text></g>';
  s += '<circle id="hb" class="blinkled" cx="352" cy="64" r="4"/>';
  const svg = `<svg viewBox="-6 -8 416 832" xmlns="${NS}" role="img" aria-label="ESP32 board drawing">${s}</svg>`;
  $('#bt-board').innerHTML = svg;
  // prepare stroke-draw animation
  $$('#bt-board .ln').forEach((el) => {
    let len = 400; try { len = Math.ceil(el.getTotalLength()) + 2; } catch (_) {}
    el.style.strokeDasharray = len; el.style.strokeDashoffset = len; el.dataset.len = len;
  });
  $$('#bt-board .show-late').forEach((t) => { t.style.opacity = 0; });
}

function drawGroup(id, dur) {
  const els = $$('#' + id + ' .ln');
  els.forEach((el, i) => {
    const d = reduced ? 0 : dur;
    el.style.transition = `stroke-dashoffset ${d}ms ease-out ${(i % 12) * (reduced ? 0 : dur / 40)}ms`;
    void el.getBoundingClientRect();
    el.style.strokeDashoffset = 0;
  });
}

function logLine(text, ok) {
  const pre = $('#bt-log');
  $$('.cur', pre).forEach((e) => e.classList.remove('cur'));
  const line = h('div', { class: 'cur' });
  line.append('> ' + text);
  if (ok) line.append(' ', h('span', { class: 'ok', text: ok }));
  pre.append(line);
  while (pre.childNodes.length > 16) pre.removeChild(pre.firstChild);
}
function setProgress(p, stage) {
  $('#bt-fill').style.width = p + '%'; $('#bt-pct').textContent = p + '%';
  if (stage) $('#bt-stage').textContent = stage;
}

async function runBoot() {
  const info = boot.info, st = boot.status;
  const dots = (k) => (k + ' ').padEnd(13, '.') + ' ';
  const na = 'N/A';
  buildBoard();
  $('#bt-log').replaceChildren();
  $('#bt-board').classList.remove('done');
  setProgress(0, 'POWER');

  const fw = info ? info.firmware : '1.0.0';
  const chip = info ? `${info.chip} REV ${info.revision}` : na;
  const cores = info ? `${info.cores} CORES @ ${info.cpuMHz} MHZ` : na;
  const flash = info ? `${Math.round(info.flashBytes / 1024)} KB` : na;
  const fs = info ? `LITTLEFS ${Math.round(info.fsUsed / 1024)}/${Math.round(info.fsTotal / 1024)} KB` : na;
  const wifi = st ? `"${st.wifi.ssid}" ${st.wifi.ip} CH${st.wifi.channel}` : na;
  const bt = st ? `BLE ${st.bluetooth.ble.advertising ? 'ADVERTISING' : 'OFF'} / CLASSIC HW ONLY` : na;
  const gpio = st ? `${st.gpio.outputs.length} OUT / ${st.gpio.inputs.length} IN CONFIGURED` : na;
  const heap = st ? kb(st.heap.free) : na;

  const T = reduced ? 0.15 : 0.85;
  const timeline = [
    [0,    () => { logLine('JARVIS BIOS v' + fw + ' // COLD BOOT'); drawGroup('g-outline', 900); setProgress(4, 'POWER'); }],
    [450,  () => { logLine(dots('CHIP') + chip, 'OK'); setProgress(10); }],
    [950,  () => { logLine(dots('CORES') + cores, 'OK'); drawGroup('g-usb', 700); drawGroup('g-btn', 700); setProgress(18, 'I/O'); }],
    [1550, () => { logLine(dots('FLASH') + flash, 'OK'); drawGroup('g-pads', 600); drawGroup('g-ic', 900); setProgress(28); }],
    [2150, () => { logLine(dots('FILESYSTEM') + fs, 'MOUNTED'); $('#qfn').classList.add('lit'); $('#reg').classList.add('lit'); setProgress(38, 'FS'); }],
    [2500, () => { drawGroup('g-pass', 900); drawGroup('g-trace', 1100); setProgress(46); }],
    [2900, () => { logLine(dots('WIFI AP') + wifi, 'ONLINE'); setProgress(55, 'RADIO'); }],
    [3500, () => { drawGroup('g-mod', 1300); setProgress(64); }],
    [4300, () => { $('#module').classList.add('lit'); $$('#bt-board .show-late').forEach((t) => { t.style.opacity = .85; }); drawGroup('g-ant', 800); logLine(dots('BLUETOOTH') + bt, 'READY'); setProgress(74, 'BT'); }],
    [5200, () => { logLine(dots('GPIO') + gpio, 'OK'); setProgress(82, 'GPIO'); $$('#g-labels text').forEach((t) => t.classList.add('show')); litPins(); }],
    [6200, () => { logLine(dots('HEAP FREE') + heap, 'OK'); setProgress(92, 'MEM'); }],
    [6600, () => { logLine(dots('SESSION') + 'TOKEN ISSUED', 'OK'); setProgress(97, 'AUTH'); }],
    [7000, () => { logLine('HANDOFF -> COMMAND CENTER'); setProgress(100, 'ONLINE'); $('#bt-board').classList.add('done'); $('#hb').style.opacity = 1; }],
  ];
  const t0 = performance.now();
  for (const [ms, fn] of timeline) {
    const wait = ms * T - (performance.now() - t0);
    if (wait > 0) await sleep(wait);
    fn();
  }
  await sleep(1100 * T);
}

function litPins() {
  const pins = $$('#g-pins .pin');
  pins.forEach((p, idx) => {
    const i = +p.dataset.i, order = i * 2 + (p.dataset.s === 'R' ? 1 : 0);
    setTimeout(() => p.classList.add('lit'), reduced ? 0 : order * 26);
  });
}

/* ======================================================================
   SCREEN 1 : COMMAND CENTER
   ====================================================================== */
const ASCII = ["+----------------.--------.----------------+","|         .----. |        | .----.         |","| (O)     |BOOT| | USB-C  | | EN |  @  (O) |","|         '----' |        | '----'         |","|                '--------'                |","|  #    :::::           ::::::          #  |","|  o                                    o  |","|  o    +--------+    [=]+---------+    o  |","|     = |        | =     |         |       |","|  o  = | ::::   | =  [=]| SOT-223 |    o  |","|  o  = | ::::   | =     |         |    o  |","|     = |        | =  [=]|         |       |","|  o    +--------+       +---------+    o  |","|  o             .--.                   o  |","|      [#] [#] [#]   [##]  [#] [##]        |","|  o                                    o  |","|      |=||=||=||=||=||=||=||=||=||=|      |","|  o                                    o  |","|  o                           o        o  |","|        +------------------------+        |","|  o    :|                        |:    o  |","|  o    :|FCC ID:2AC7Z-ESPWROOM32 |:    o  |","|       :|                        |:       |","|  o    :|211-161007      [R]     |:    o  |","|       :|                        |:       |","|  o    :| (o)  CE   ((.))        |:    o  |","|  o    :|                        |:    o  |","|       :|                        |:       |","|  o    :|                        |:    o  |","|  o    :|E S P - W R O O M - 3 2 |:    o  |","|       :|                        |:       |","|  o    :| .:.:.:.:.:.:.:.:.:.:.  |:    o  |","|       :|                        |:       |","|  o     +------------------------+     o  |","|            .-.   .-.   .-.   .-.         |","|            | |   | |   | |   | |         |","| (O)        '-'---'-'---'-'---'-'     (O) |","|                                          |","+------------------------------------------+"];
const I2C_HINTS = { 0x3C: 'SSD1306 OLED', 0x3D: 'SSD1306 OLED', 0x27: 'PCF8574 LCD backpack', 0x3F: 'PCF8574A LCD backpack',
  0x68: 'MPU6050 / DS3231', 0x69: 'MPU6050', 0x76: 'BME280 / BMP280', 0x77: 'BME280 / BMP280 / BMP180', 0x48: 'ADS1115 / PCF8591',
  0x40: 'INA219 / PCA9685 / HTU21D', 0x23: 'BH1750', 0x5A: 'MLX90614 / CCS811', 0x29: 'VL53L0X / TSL2561', 0x57: 'AT24C32 EEPROM' };

const dash = {
  timer: 0, running: false, fails: 0, rebooting: false, outSig: '', inSig: '', last: null, info: null,
  start() {
    if (this.running) return;
    this.running = true; this.fails = 0;
    this.info = boot.info;
    if (!$('#ascii').childNodes.length) drawAscii();
    this.tick();
  },
  stop() { this.running = false; clearTimeout(this.timer); },
  async tick() {
    if (!this.running) return;
    clearTimeout(this.timer);
    const t0 = performance.now();
    try {
      if (!this.info) { const i = await api('/api/info', { timeout: 4000 }); if (i.ok) this.info = i.data; }
      const r = await api('/api/status', { timeout: 4000 });
      if (!this.running) return;
      if (r.status === 401) return;
      if (!r.ok || !r.data) throw new Error('bad status');
      this.fails = 0;
      render(r.data, this.info, Math.round(performance.now() - t0));
      banner(null);
    } catch (e) {
      if (!this.running) return;
      this.fails++;
      setLink(false);
      if (this.rebooting) banner('REBOOTING - WAITING FOR JARVIS TO COME BACK...');
      else if (this.fails >= 2) banner('LINK LOST - RETRYING (' + this.fails + ')  CHECK YOU ARE STILL ON THE "JARVIS" WI-FI');
    }
    if (this.running && !document.hidden) this.timer = setTimeout(() => this.tick(), 2000);
    else if (this.running) this.timer = setTimeout(() => this.tick(), 4000);
  },
  now() { this.tick(); },
};

function drawAscii() {
  const pre = $('#ascii'); pre.replaceChildren();
  for (const line of ASCII) {
    const parts = line.split('@');
    pre.append(parts[0]);
    if (parts.length > 1) pre.append(h('span', { class: 'led-a', text: '*' }), parts[1]);
    pre.append('\n');
  }
}

function banner(msg) {
  const b = $('#d-banner');
  if (!msg) { b.hidden = true; return; }
  b.textContent = '! ' + msg; b.hidden = false;
}
function setLink(ok, lat) {
  const l = $('#d-link'); l.classList.toggle('bad', !ok);
  $('#d-link-text').textContent = ok ? 'LINK OK' : 'NO LINK';
  $('#ro-link').textContent = ok ? 'ONLINE' : 'LOST';
  if (ok) $('#ro-lat').textContent = lat + ' ms';
}
const setK = (k, v, cls) => { const e = $(`[data-k="${k}"]`); if (e) { e.textContent = v; e.classList.toggle('warn', !!cls); } };

function render(s, info, lat) {
  dash.last = s;
  setLink(true, lat);
  setK('uptime', fmtUptime(s.uptime));
  $('#ro-uptime').textContent = fmtUptime(s.uptime);
  if (info) {
    setK('chip', `${info.chip} rev ${info.revision} (${info.cores} cores)`);
    setK('cpu', info.cpuMHz + ' MHz');
    setK('flash', Math.round(info.flashBytes / 1048576 * 10) / 10 + ' MB');
    setK('fw', info.device + ' v' + info.firmware);
    setK('fs', Math.round(info.fsUsed / 1024) + ' / ' + Math.round(info.fsTotal / 1024) + ' KB');
  }
  setK('heap', `${kb(s.heap.free)}  (low ${kb(s.heap.min)})`);
  setK('temp', s.tempC == null ? 'N/A' : s.tempC.toFixed(1) + ' °C (approx.)');

  // Wi-Fi
  const w = s.wifi;
  setK('w-mode', 'ACCESS POINT (this page is served over it)');
  setK('w-ssid', w.ssid); setK('w-ip', w.ip); setK('w-ch', String(w.channel));
  setK('w-clients', `${w.clients} / ${w.maxClients}`);
  const ul = $('#w-stations');
  ul.replaceChildren(...(w.stations.length
    ? w.stations.map((c) => h('li', { class: 'stn' }, 'client ', h('b', { text: c.mac }), '  ' + c.rssi + ' dBm'))
    : [h('li', { class: 'dim', text: 'no client details reported' })]));
  $$('#tx-chips .chip').forEach((c) => c.classList.toggle('on', +c.dataset.level === w.txLevel));

  // Bluetooth
  const b = s.bluetooth;
  setK('bt-classic', 'hardware: YES  /  firmware: NOT IMPLEMENTED');
  setK('bt-ble', `hardware: YES  /  ${b.ble.advertising ? 'ADVERTISING' : 'OFF'}`);
  setK('bt-name', b.ble.name);
  setK('bt-links', b.ble.advertising ? String(b.ble.connections) : '-');
  $$('#ble-chips .chip').forEach((c) => c.classList.toggle('on', (c.dataset.state === '1') === b.ble.advertising));

  renderOutputs(s.gpio.outputs);
  renderInputs(s.gpio.inputs);
  renderI2c(s.i2c);
}

const pinLabel = (p) => 'GPIO' + pad2(p);

function renderOutputs(list) {
  const ul = $('#g-outputs');
  const sig = list.map((o) => [o.id, o.pin, o.name, o.blocked, o.activeHigh].join(':')).join('|');
  if (sig !== dash.outSig) {
    dash.outSig = sig;
    ul.replaceChildren(...(list.length ? list.map(buildOutRow)
      : [h('li', { class: 'empty', text: 'no outputs configured (edit include/config.h)' })]));
  }
  for (const o of list) {
    const li = ul.querySelector(`li[data-id="${o.id}"]`); if (!li) continue;
    li.querySelectorAll('.chip').forEach((c) => c.classList.toggle('on', !o.blocked && (c.dataset.state === '1') === o.on));
    li.querySelector('.lvl').textContent = o.blocked ? 'BLOCKED' : 'LEVEL: ' + (o.level ? 'HIGH' : 'LOW');
  }
}
function buildOutRow(o) {
  const li = h('li', { 'data-id': o.id, class: o.blocked ? 'blocked' : '' });
  const left = h('div', null, h('span', { class: 'nm', text: o.name }), h('div', { class: 'meta', text: `${pinLabel(o.pin)} // ACTIVE ${o.activeHigh ? 'HIGH' : 'LOW'}` }));
  const right = h('div', { class: 'chips' });
  for (const [st, label] of [['1', '[ON]'], ['0', '[OFF]']]) {
    const c = h('button', { class: 'chip', text: label, type: 'button', disabled: !!o.blocked });
    c.dataset.state = st;
    c.addEventListener('click', () => act(c, () => api('/api/gpio', { form: { id: o.id, state: st } })));
    right.append(c);
  }
  right.append(h('span', { class: 'meta lvl', text: '--' }));
  li.append(left, right);
  return li;
}
function renderInputs(list) {
  const ul = $('#g-inputs');
  const sig = list.map((i) => i.name + i.pin).join('|');
  if (sig !== dash.inSig) {
    dash.inSig = sig;
    ul.replaceChildren(...(list.length ? list.map((i) => h('li', { 'data-in': i.name },
      h('div', null, h('span', { class: 'nm', text: i.name }), h('div', { class: 'meta', text: pinLabel(i.pin) + ' // READ-ONLY' })),
      h('span', { class: 'meta st', text: '--' })))
      : [h('li', { class: 'empty', text: 'no inputs configured' })]));
  }
  for (const i of list) {
    const li = ul.querySelector(`li[data-in="${i.name}"]`); if (!li) continue;
    const st = li.querySelector('.st'); st.textContent = i.active ? '[ ACTIVE ]' : '[ idle ]';
    st.style.color = i.active ? 'var(--g-hi)' : ''; st.style.fontWeight = i.active ? '700' : '';
  }
}
function renderI2c(i) {
  $('#i2c-pins').textContent = `> bus: SDA GPIO${i.sda} / SCL GPIO${i.scl}. Needs pull-up resistors (most modules have them).`;
  const btn = $('#btn-i2c'), ul = $('#i2c-found');
  const scanning = i.state === 'scanning';
  btn.textContent = scanning ? 'Scanning...' : 'Scan';
  btn.classList.toggle('busy', scanning); btn.disabled = scanning;
  if (i.state === 'done') {
    ul.replaceChildren(...(i.found.length ? i.found.map((a) => h('li', null,
      h('div', null, h('span', { class: 'nm', text: '0x' + a.toString(16).toUpperCase().padStart(2, '0') }),
        h('div', { class: 'meta', text: I2C_HINTS[a] ? 'possible: ' + I2C_HINTS[a] : 'unknown device' }))))
      : [h('li', { class: 'empty', text: 'no device answered. Check wiring, power and pull-ups.' })]));
  } else if (!scanning) ul.replaceChildren();
}

/* ---- actions with loading / error states ---- */
async function act(btn, fn, after) {
  if (btn.disabled) return;
  btn.disabled = true; btn.classList.add('busy'); btn.classList.remove('err');
  try {
    const r = await fn();
    if (!r.ok) throw new Error((r.data && r.data.error) || 'HTTP ' + r.status);
    if (after) await after();
    dash.now();
  } catch (e) {
    btn.classList.add('err'); setTimeout(() => btn.classList.remove('err'), 1000);
    banner(e.net ? 'NO RESPONSE FROM JARVIS' : 'COMMAND FAILED: ' + e.message);
    setTimeout(() => { if (dash.fails < 2) banner(null); }, 3500);
  } finally {
    btn.classList.remove('busy'); btn.disabled = false;
  }
}

function wireDash() {
  $$('#tx-chips .chip').forEach((c) => c.addEventListener('click', () =>
    act(c, () => api('/api/wifi/txpower', { form: { level: c.dataset.level } }))));

  $$('#ble-chips .chip').forEach((c) => c.addEventListener('click', () =>
    act(c, () => api('/api/bluetooth', { form: { state: c.dataset.state } }), async () => {
      // BLE is switched in the firmware main loop: wait until status confirms it
      const want = c.dataset.state === '1';
      for (let n = 0; n < 8; n++) {
        await sleep(450);
        const r = await api('/api/status');
        if (r.ok && r.data.bluetooth.ble.advertising === want) return;
      }
      throw new Error('BLE DID NOT CHANGE STATE');
    })));

  $('#btn-i2c').addEventListener('click', () => act($('#btn-i2c'), () => api('/api/i2c/scan', { method: 'POST' })));

  // reboot: two-step [y]/[n]
  const y = $('#btn-reboot-y'), n = $('#btn-reboot-n'), yn = $('.yn');
  let armed = false;
  const disarm = () => { armed = false; y.textContent = '[y]'; n.hidden = true; yn.textContent = '[ y / n ]'; };
  n.addEventListener('click', disarm);
  y.addEventListener('click', async () => {
    if (!armed) { armed = true; y.textContent = '[y] CONFIRM'; n.hidden = false; yn.textContent = 'REBOOT JARVIS?'; return; }
    disarm();
    await act(y, () => api('/api/reboot', { method: 'POST' }), async () => {
      dash.rebooting = true; banner('REBOOTING - WAITING FOR JARVIS TO COME BACK...');
    });
  });

  $('#btn-logout').addEventListener('click', async () => {
    try { await api('/api/logout', { method: 'POST' }); } catch (_) { /* ignore */ }
    sessionLost('SESSION CLOSED');
  });
}

/* ---- session end -> back to login ---- */
let leaving = false;
async function sessionLost(msg) {
  if (leaving) return; leaving = true;
  dash.stop(); dash.rebooting = false; dash.info = null; dash.outSig = dash.inSig = '';
  boot = { info: null, status: null };
  banner(null);
  await show('login');
  login.lines = []; logSet('LINK', 'OK'); logSet('AUTH', msg, msg === 'SESSION CLOSED' ? '' : 'bad');
  setLed('led-auth', ''); setBtn('[ AUTHENTICATE ]', false);
  leaving = false;
  $('#in-user').focus();
}

/* ======================================================================
   init
   ====================================================================== */
async function init() {
  $('#lf-host').textContent = location.host || '192.168.4.1';
  $('#login-form').addEventListener('submit', onLoginSubmit);
  wireDash();
  window.addEventListener('resize', () => { if (login.active) { drawTunnel(performance.now()); drawSkull(performance.now()); } });
  document.addEventListener('visibilitychange', () => { if (!document.hidden && dash.running) dash.now(); });

  let authed = false;
  try { const r = await api('/api/session', { timeout: 3500 }); authed = !!(r.ok && r.data && r.data.authenticated); }
  catch (_) { /* offline: show login, user will see LINK FAULT on submit */ }

  if (authed) {                                   // page reload with a valid session
    await show('dash'); dash.start();
  } else {
    logSet('LINK', 'OK'); logSet('AUTH', 'STANDBY');
    await show('login');
    $('#in-user').focus();
  }
}
init();

})();
