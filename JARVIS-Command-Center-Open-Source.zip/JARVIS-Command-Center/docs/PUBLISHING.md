# Publishing to GitHub

Nothing here has been done for you: the repository has **not** been published. These are the suggested values and exact steps.

## Suggested repository details

| Field | Suggestion |
|---|---|
| Name | `jarvis-esp32-command-center` |
| Description | Retro green-terminal web command center served by an ESP32 from its own Wi-Fi access point (PlatformIO, LittleFS, ESPAsyncWebServer). |
| Topics | `esp32` `platformio` `arduino` `littlefs` `espasyncwebserver` `access-point` `web-dashboard` `iot` `embedded` `cyberpunk-ui` `terminal-ui` `maker` |
| Visibility | Public, after the checklist below |

## Pre-publish checklist

1. `include/secrets.h` exists only on your machine and is **not** in the folder you commit from (or is ignored).
2. Run `git status` after `git add .` and confirm `secrets.h` is not listed.
3. Decide the license (next section).
4. Optionally pin `platform` and library versions in `platformio.ini` once a build succeeds on your machine.
5. If this folder was ever pushed/zipped with real passwords, change them first — see [SECURITY.md](../SECURITY.md).

## License decision (awaiting your confirmation)

No license is applied. `LICENSE.PROPOSED-MIT.txt` is a proposal with "Copyright (c) 2026 ADITECHSMITH".

**MIT (recommended for a learning/maker project):** anyone may use, modify, redistribute and sell it, including in closed
projects, as long as the copyright notice and license text are kept; it comes with no warranty and no liability.
If you prefer that improvements stay open, consider GPL-3.0 or Apache-2.0 (adds a patent grant) instead. Without any license,
others legally cannot reuse the code.

To accept MIT:

```bash
git mv LICENSE.PROPOSED-MIT.txt LICENSE
```

then edit the **License** section of `README.md` to say "MIT" and remove the "No license has been selected yet" text, and update the
changelog line. Check the copyright name/year first. The bundled fonts keep their own licenses
([THIRD_PARTY_NOTICES.md](../THIRD_PARTY_NOTICES.md)).

## Commands

Create an **empty** public repository on github.com (no README/license/gitignore), then in the project folder:

```bash
git init
git add .
git status          # verify include/secrets.h is NOT listed
git commit -m "Initial release: JARVIS Command Center for ESP32"
git branch -M main
git remote add origin https://github.com/<your-username>/jarvis-esp32-command-center.git
git push -u origin main
```

Then, on GitHub: add the description and topics, enable *Private vulnerability reporting* (Settings → Code security), and create the release:

```bash
git tag -a v1.0.0 -m "JARVIS Command Center 1.0.0"
git push origin v1.0.0
```

## Initial commit message

```text
Initial release: JARVIS Command Center for ESP32
```

## Release description (v1.0.0)

> **JARVIS Command Center 1.0.0 — first public release**
>
> A retro green-terminal command center hosted by an ESP32-WROOM-32 on its own Wi-Fi access point.
> Log in, watch the boot animation, then view system info and control the GPIO pins you explicitly allow.
>
> **Highlights:** firmware-side login with session cookies and lockout · offline UI with local fonts · system, Wi-Fi, BLE-advertising, GPIO and I2C panels · full docs and a mock server for UI work without hardware.
>
> **Please note:** hobby-grade security (plain HTTP, compiled-in credentials). The firmware build and access point are reported working by the author; GPIO, BLE, I2C, TX power and reboot are **not yet verified on hardware**. You must create `include/secrets.h` from `include/secrets.example.h` and upload both the firmware and the filesystem image — see the README.
>
> Built by ADITECHSMITH — [@aditechsmith](https://www.instagram.com/aditechsmith?obrf=MXZlOWpub2k2M3RrbQ==)
