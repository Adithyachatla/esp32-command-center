# Features and implementation status

Back to the [README](../README.md).

**Legend.** *Implemented* = the code exists in this repository. *UI tested* = exercised in headless Chrome against
the simulated API in `tools/mock-server.js`. *Hardware* = verified on a real ESP32 board.

| Feature | Implemented | UI tested | Hardware |
|---|:--:|:--:|---|
| Wi-Fi access point (WPA2) | yes | n/a | Reported working by the author |
| Static frontend from LittleFS | yes | yes | Reported reaching the web server; full UI not independently confirmed |
| Login (credentials checked in firmware) | yes | yes | Not independently confirmed |
| Session cookie, idle expiry, max 3 sessions | yes | yes | Untested |
| Per-IP lockout (5 tries → 60 s, ×2…×8) | yes | yes (shortened lock in mock) | Untested |
| ACCESS GRANTED + boot animation | yes | yes | Untested |
| System info (uptime, chip, CPU, flash, heap, FS) | yes | yes | Untested |
| Chip temperature | yes | n/a | Untested; may show `N/A` on some core versions |
| Wi-Fi panel (SSID, IP, channel, clients, RSSI) | yes | yes | Untested |
| TX power LOW / MED / HIGH | yes | yes | Untested |
| BLE advertising on/off + connection count | yes | yes | Untested |
| Classic Bluetooth | **no** — hardware exists, firmware does not use it | — | — |
| GPIO outputs (configured pins only) | yes | yes | Untested |
| GPIO inputs (read-only) | yes | yes | Untested |
| I2C scanner (SDA 21 / SCL 22) | yes | yes | Untested |
| Reboot (two-step confirm) | yes | partly | Untested |
| Logout | yes | yes | Untested |
| Offline fonts | yes | yes (all four load) | Untested |
| `SLOT_A` / `SLOT_B` module placeholders | placeholder only | — | — |
| Creator credit bottom-right on every screen | yes | yes | — |

## Feature notes

- **Login & sessions.** The browser POSTs `user` and `pass` to `/api/login`. The firmware compares them in constant time
  with the values in `include/secrets.h`. The session token is 128 bits from the hardware RNG and lives in an
  `HttpOnly`, `SameSite=Strict` cookie. Sessions exist only in RAM. See [SECURITY.md](../SECURITY.md).
- **Boot animation.** The log lines show values fetched from `/api/info` and `/api/status` (chip, flash, filesystem, SSID,
  heap). If a value is unavailable the line shows `N/A` rather than a made-up number.
- **BLE.** Starting and stopping BLE is queued by the API and executed from `loop()`. It advertises the name `JARVIS`; there
  are no services or characteristics.
- **GPIO.** The dashboard can only see and drive what `include/config.h` lists. `LEVEL` is read back from the pin; whether
  anything is wired to it is unknown to JARVIS. See [HARDWARE.md](HARDWARE.md).
- **I2C.** The scan runs from `loop()`; the dashboard polls for the result.
- **Desktop only.** The layout targets a laptop browser (`min-width: 1100px`); there are no phone breakpoints.
