# Architecture

Back to the [README](../README.md).

## Overview

```mermaid
flowchart LR
    B["Laptop · Chrome<br/>http://192.168.4.1/"] -- "Wi-Fi (WPA2)" --> AP
    subgraph ESP32["ESP32-WROOM-32"]
        AP["SoftAP"] --> WS["ESPAsyncWebServer :80"]
        WS --> FS[("LittleFS<br/>index.html · style.css<br/>script.js · fonts/")]
        WS --> AU["auth.cpp<br/>sessions · lockout"]
        WS --> API["api.cpp<br/>/api/* routes"]
        API --> HW["hardware.cpp<br/>GPIO · BLE · I2C · TX power"]
        LP["loop()"] --> HW
    end
```

```mermaid
sequenceDiagram
    participant U as Browser
    participant E as ESP32
    U->>E: GET /  (index.html, style.css, script.js, fonts)
    U->>E: GET /api/session
    E-->>U: authenticated: false
    U->>E: POST /api/login (user, pass)
    alt correct
        E-->>U: 200 + Set-Cookie JARVIS_SID (HttpOnly)
        U->>E: GET /api/info, /api/status
        E-->>U: real device data
        Note over U: ACCESS GRANTED → boot animation → dashboard
    else wrong
        E-->>U: 401 ACCESS DENIED (+ attempts left)
    else too many tries
        E-->>U: 429 LOCKED (retryAfter seconds)
    end
```

## Boot sequence (`src/main.cpp`)

1. Serial banner at 115200 baud.
2. `LittleFS.begin(false)` — **never auto-formats**. A failure prints `MOUNT FAILED` and the server answers with a hint page.
3. `Hardware::begin()` (GPIO) and `Auth::begin()`.
4. `WiFi.softAP(JARVIS_AP_SSID, JARVIS_AP_PASSWORD, channel, hidden, maxClients)`, then TX power HIGH.
5. `Api::begin(server, fsOk)` registers routes; `server.begin()` listens on port 80.
6. `loop()` only calls `Hardware::service()` and `delay(10)`.

## Modules

| File | Responsibility |
|---|---|
| `src/main.cpp` | Boot sequence only |
| `src/api.cpp` / `api.h` | All routes, hand-built JSON (no ArduinoJson), static file serving, `/fonts/*` handler, 404 handler |
| `src/auth.cpp` / `auth.h` | RAM session table, `esp_random()` tokens, constant-time compare, per-IP attempt table |
| `src/hardware.cpp` / `hardware.h` | GPIO allow-list, BLE, I2C scan, TX power, reboot, chip temperature |
| `include/config.h` | Pins, limits, timings |
| `include/secrets.h` | AP SSID/password and dashboard login (git-ignored; template: `secrets.example.h`) |

### Deferred work

The web server runs in its own task, so slow operations are only *requested* there and executed from `loop()`:

| Request | Executed by |
|---|---|
| `POST /api/bluetooth` | `Hardware::service()` → `startBle()` / `stopBle()` |
| `POST /api/i2c/scan` | `Hardware::service()` → `doI2cScan()` |
| `POST /api/reboot` | `Hardware::service()` after ≈0.8 s |

The dashboard polls `/api/status` every 2 s to see the result.

## HTTP API

| Route | Session needed | Purpose |
|---|:--:|---|
| `GET /api/session` | no | `{authenticated}` (used on page reload) |
| `POST /api/login` | no | form `user`, `pass` → `200` + cookie / `401` / `429` |
| `POST /api/logout` | no | clears the caller's session if present |
| `GET /api/info` | yes | chip, cores, flash, firmware, filesystem size |
| `GET /api/status` | yes | uptime, heap, Wi-Fi, Bluetooth, GPIO, I2C |
| `POST /api/gpio` | yes | `id`, `state` (0/1) — configured outputs only |
| `POST /api/bluetooth` | yes | `state` (0/1) |
| `POST /api/wifi/txpower` | yes | `level` 0 / 1 / 2 |
| `POST /api/i2c/scan` | yes | starts a scan |
| `POST /api/reboot` | yes | restarts the board |

Requests are `application/x-www-form-urlencoded`; responses are JSON. Every POST also requires the `Origin` header (if present) to match `Host`.
Error bodies look like `{"ok":false,"error":"UNAUTHORIZED"}`.

## Filesystem and partitions

- `board_build.filesystem = littlefs`, `board_build.partitions = huge_app.csv` (≈3 MB app, ≈1 MB filesystem, **no OTA**).
  Wi-Fi + BLE does not fit the default 1.2 MB app slot.
- `data/` is packed by `pio run -t buildfs` and written by `pio run -t uploadfs` — independent of the firmware upload.
- `/fonts/*` is served by a dedicated handler so `.woff2` gets `Content-Type: font/woff2`; everything else is `serveStatic("/", LittleFS, "/")`
  with `no-cache`.

## Frontend (`data/`)

| File | Role |
|---|---|
| `index.html` | Four screens: login, access granted, boot, dashboard; plus the fixed creator credit |
| `style.css` | Phosphor-green theme, CRT scan-lines, desktop-only layout, `@font-face` rules for `fonts/*.woff2` |
| `script.js` | One IIFE: `api()` wrapper, screen manager, login canvas effects, boot timeline + SVG board, 2-second polling, actions with loading/error states |

No external requests are made — the ESP32 access point has no internet. No credentials or tokens are stored in browser storage.
