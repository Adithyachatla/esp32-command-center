# Troubleshooting

Back to the [README](../README.md). Always look at the serial monitor first (`pio device monitor`, 115200 baud).
**Redact SSIDs, passwords and MAC addresses before posting logs anywhere public.**

## Build and upload

| Symptom | Likely cause | Fix |
|---|---|---|
| `secrets.h: No such file or directory` | Credentials file not created | `copy include\secrets.example.h include\secrets.h`, then edit it. |
| Build error mentioning ESPAsyncWebServer / AsyncTCP | Stale or duplicate library copies | Run `pio run -t clean`, delete `.pio\libdeps`, build again; make sure nothing extra sits in `lib\`. |
| Toolchain/library download fails | No internet on the first build, proxy/firewall, SSL inspection | Connect to the internet for the first build; check proxy/antivirus HTTPS scanning; retry. |
| Build breaks after a PlatformIO/platform update | `platform` is not version-pinned | Pin `platform = espressif32@<version that worked for you>` in `platformio.ini`. |
| `Failed to connect to ESP32: Timed out waiting for packet header` | Not in download mode, bad cable, port busy | Hold **BOOT** while uploading; use a data cable; close the serial monitor and any browser serial tabs. |
| Windows shows no COM port | Missing USB-serial driver | Install the CP210x or CH340 driver that matches your board's USB chip. |
| Wrong or unknown COM port | PlatformIO picked another device | `pio device list`, then set `upload_port` / `monitor_port` in `platformio.ini`. |
| `could not open port 'COMx'` / access denied | Another program holds the port | Close the serial monitor, Arduino IDE, browser serial pages; replug the board. |

## Filesystem (LittleFS) and the web page

| Symptom | Likely cause | Fix |
|---|---|---|
| Page says **"filesystem not mounted"** | Filesystem image not uploaded, or mount failed | Close the monitor → `pio run -t buildfs` → `pio run -t uploadfs` → press **EN**. Serial must show `[FS] LittleFS mounted`. |
| Still `[FS] MOUNT FAILED` after a successful filesystem upload | `data/` is not in the project root, or the flash layout changed since an old upload | `data/` must sit next to `platformio.ini` and be named `data`. Run **Erase Flash** (Project Tasks → Platform), then upload firmware, then the filesystem image. |
| Page loads but looks unstyled / wrong fonts | Old or incomplete image; wrong font file names | Check the four lowercase names in `data/fonts/` (`jbmono-400`, `jbmono-700`, `pressstart2p`, `silkscreen-bold`, `.woff2`); re-upload the filesystem; hard-refresh (Ctrl+F5). File names are case-sensitive on the board. |
| Your edits to `data/` don't show | Filesystem not re-uploaded, or browser cache | `pio run -t uploadfs`, then Ctrl+F5. |
| Filesystem upload fails / "port busy" | Serial monitor open | Close it and retry. |
| Boot log lists no `fonts/` entries | Fonts missing from `data/fonts/` | Copy the four `.woff2` files into `data/fonts/` and re-upload the filesystem. |

## Wi-Fi and connecting

| Symptom | Likely cause | Fix |
|---|---|---|
| Can't see the Wi-Fi network | The access point failed to start | Look for `softAP FAILED` in serial. The password must be 8–63 characters. Reset the board. |
| Can't join the network | Wrong password, or `JARVIS_AP_HIDDEN` is true | Re-check `secrets.h` (rebuild + upload firmware after editing); check `config.h`. |
| Windows says "no internet" | Expected — the ESP32 network has no internet | Stay connected. |
| Browser can't reach `192.168.4.1` | Wrong network (mobile data / other Wi-Fi), or `https://` | Join the ESP32 network and type `http://192.168.4.1/`. |
| Page disconnects after lowering TX power | Signal too weak | Set TX power back to HIGH, or move closer. |

## Login and sessions

| Symptom | Likely cause | Fix |
|---|---|---|
| Always `ACCESS DENIED` | Different credentials than the flashed ones, or you edited `secrets.h` without re-flashing | Re-check `include/secrets.h`; `pio run -t upload`. Values are case-sensitive; max 63 characters each. |
| Button shows `LOCKED` | Lockout after 5 wrong tries (60 s, longer after repeats) | Wait for the countdown or reset the board. |
| Back at the login screen after a reboot or long idle | Sessions are RAM-only, 30-minute idle timeout | Expected — log in again. |
| `SESSION EXPIRED` | Idle timeout, another login replaced your session (max 3), or the board rebooted | Log in again. |

## Stability and memory

| Symptom | Likely cause | Fix |
|---|---|---|
| Reset loop with `Brownout detector was triggered` | Weak USB port/cable (Wi-Fi + BLE draw current peaks) | Different port or cable, or a powered hub. |
| Random resets or slowness with BLE on | Memory pressure — Wi-Fi + BLE use a lot of RAM | Turn BLE off; watch `HEAP FREE` on the dashboard. |
| Several browser tabs misbehave | Each tab polls every 2 s; the board is small | Use one tab; at most 4 Wi-Fi clients are allowed. |
| Chip temp shows `N/A` | Not available on some core versions | Normal. |
| Output shows `BLOCKED` | Pin is not on the safe-pin allow-list | Use one of `2 4 5 13 14 15 16 17 18 19 23 25 26 27 32 33` — see [HARDWARE.md](HARDWARE.md). |

## Still stuck?

Open an issue with: board model, Windows version, PlatformIO version, the **redacted** serial log and the exact error text.
Never include real passwords or personal paths.
