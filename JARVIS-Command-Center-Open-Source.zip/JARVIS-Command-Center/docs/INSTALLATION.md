# Installation guide (Windows)

A beginner-friendly walkthrough from an empty laptop to a running dashboard.
Back to the [README](../README.md) · Problems? See [TROUBLESHOOTING](TROUBLESHOOTING.md).

> **Verification note.** Compile, flash and the Wi-Fi/web server are reported working by the author on a real
> board. The full UI from LittleFS and the hardware actions (GPIO, BLE, I2C, TX power, reboot) are
> **not yet independently verified on hardware**; the optional checks in step 12 are how you verify them.

## 0. What you need

- An **ESP32-WROOM-32** development board (PlatformIO board `esp32dev`)
- A USB **data** cable (a charge-only cable cannot flash)
- A Windows laptop with Wi-Fi and Google Chrome
- Internet access for the *first build only* (PlatformIO downloads the toolchain and libraries)

## 1. Install Visual Studio Code

Download it from <https://code.visualstudio.com/> and install with the default options.

## 2. Install PlatformIO IDE

In VS Code open **Extensions** (Ctrl+Shift+X), search for **PlatformIO IDE**, click **Install**, then restart VS Code
when asked. A new alien-head icon appears in the left bar. The first start installs PlatformIO Core — wait for it to finish.

## 3. Install the USB-serial driver (if needed)

Plug the board in. If **Device Manager → Ports (COM & LPT)** shows no new COM port, install the driver for your
board's USB chip (usually **CP210x** or **CH340**; the chip is printed on the board).

## 4. Open the project

*File → Open Folder…* → choose the folder that contains `platformio.ini`. PlatformIO detects the project automatically.

## 5. Create your private credentials file

The repository contains a template, **not** your credentials:

```bat
copy include\secrets.example.h include\secrets.h
```

Open `include/secrets.h` and put in **your own** values:

```cpp
#define JARVIS_AP_SSID       "YOUR_WIFI_SSID"        // the network the ESP32 creates
#define JARVIS_AP_PASSWORD   "YOUR_WIFI_PASSWORD"    // 8-63 characters
#define JARVIS_LOGIN_USER    "YOUR_LOGIN_USER"       // dashboard login (max 63)
#define JARVIS_LOGIN_PASS    "YOUR_LOGIN_PASSWORD"   // dashboard password (max 63)
```

- Use long, unique passwords. The placeholder values in the template are **not** safe to keep.
- `include/secrets.h` is in `.gitignore`. Never commit it, post it, or paste it into issues.
- The Wi-Fi password and the dashboard password are two different things: one joins the network, the other logs in to the page.

## 6. Select the board and COM port

- **Board:** already set by `platformio.ini` (`board = esp32dev`). Nothing to select.
- **COM port:** PlatformIO normally auto-detects it. To see what it finds:
  ```bat
  pio device list
  ```
  If the wrong port is used, add your port to `platformio.ini` under `[env:esp32dev]`:
  ```ini
  upload_port = COM5
  monitor_port = COM5
  ```
  (Replace `COM5` with yours; it is the port that appears when you plug the board in.)

## 7. Build the firmware

Sidebar → **Project Tasks → esp32dev → General → Build**, or in the PlatformIO terminal:

```bat
pio run
```

Expected: `SUCCESS`. The first build can take several minutes. If it says `secrets.h: No such file`, repeat step 5.

## 8. Upload the firmware

```bat
pio run -t upload
```

(or **General → Upload**). If it stops at `Connecting....`, hold the board's **BOOT** button until the upload starts.

## 9. Build and upload the filesystem image

This packs everything in `data/` (HTML, CSS, JS, fonts) into a LittleFS image and flashes it to a **separate**
region of the chip. **Close the serial monitor first.**

```bat
pio run -t buildfs
pio run -t uploadfs
```

(or **Platform → Build Filesystem Image / Upload Filesystem Image**). Expect `SUCCESS` and a write at an address
near `0x00310000`.

> **Firmware vs filesystem.** `upload` flashes the C++ program (`src/`, `include/`). `uploadfs` flashes the web
> page (`data/`). Changing `config.h` or `secrets.h` → upload the **firmware**. Changing anything in `data/` →
> upload the **filesystem**. A fresh board needs both.

## 10. Open the serial monitor

Press the board's **EN** (reset) button, then:

```bat
pio device monitor
```

Expected (values differ per board):

```text
[SYS] chip ESP32-... rev ..., 2 core(s) @ 240 MHz, flash 4096 KB
[FS] LittleFS mounted (xx / yyyy bytes used)
  index.html (...)
  style.css (...)
  script.js (...)
  fonts/
    jbmono-400.woff2 (...)
[GPIO] output ONBOARD_LED  GPIO2  ready
[GPIO] input  BOOT_BUTTON  GPIO0  ready
[WIFI] AP "<your SSID>" up on channel 6
[WIFI] open http://192.168.4.1/
[HTTP] server started on port 80
[SYS] READY
```

`[FS] MOUNT FAILED` means step 9 was skipped or failed.

## 11. Connect and log in

1. Join the Wi-Fi network named in `secrets.h` (Windows may say "no internet" — stay connected).
2. In Chrome open **`http://192.168.4.1/`**. Type `http://` yourself; the board does not serve HTTPS.
3. Log in with your dashboard username/password.
4. You should see **ACCESS GRANTED**, the ESP32 board animation, then the command center.

`192.168.4.1` is the ESP32 SoftAP's default address.

## 12. Optional hardware checks (to verify untested features)

| Check | What it proves |
|---|---|
| `ONBOARD_LED` `[ON]`/`[OFF]` | GPIO 2 level changes (the blue LED lights on most boards; serial prints `[GPIO] ONBOARD_LED -> ON`). |
| Hold the **BOOT** button | Dashboard shows `[ ACTIVE ]` within ~2 s (GPIO 0 input). |
| BLE `[ON]` | A phone BLE scanner (e.g. nRF Connect) lists the BLE name `JARVIS`. |
| TX power | Setting changes; compare client RSSI to see the effect. |
| I2C scan | Nothing attached → "no device answered". A device on GPIO 21/22 → its address appears. |
| Reboot `[y]` → `[y] CONFIRM` | Banner "REBOOTING", then back to login (sessions are RAM-only). |
| Wrong login | `ACCESS DENIED` + tries counter; five wrong → `LOCKED` countdown. |
| Logged-out API | In a private window `http://192.168.4.1/api/status` returns `{"ok":false,"error":"UNAUTHORIZED"}`. |

## 13. Changing things later

- **Add an LED:** see [HARDWARE.md](HARDWARE.md#adding-an-output) — firmware upload only.
- **Change the look:** edit files in `data/`, run `pio run -t uploadfs`, hard-refresh Chrome (Ctrl+F5).
- **Reproducible builds:** once your build works, pin `platform = espressif32@<version>` in `platformio.ini`.
